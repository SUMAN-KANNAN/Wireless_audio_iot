#pragma once

// WiFi credentials
const char* ssid = "Airtel_hiro_9768";
const char* password = "air90249";

// Device API Key
// This key must match the DEVICE_API_KEY on the server.
const char* device_api_key = "a-very-secret-key-for-devices-only";