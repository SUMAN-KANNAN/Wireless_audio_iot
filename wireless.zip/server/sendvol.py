import os
import json
from server.sock_instance import sock

volume_log = {}

@sock.route('/ws/volume')
def volume_socket(ws):
    print("🔗 WebSocket connected (volume)")
    while True:
        try:
            message = ws.receive()
            if not message:
                break

            data = json.loads(message)
            if data.get("type") == "volume":
                for room_id, volume in data.get("data", {}).items():
                    volume_log[room_id] = volume
                    print(f"Volume for {room_id} set to {volume}%")
                save_volume_json()
        except Exception as e:
            print(f"Volume WebSocket error: {e}")
            break

def save_volume_json():
    directory = "saved_volume"
    os.makedirs(directory, exist_ok=True)
    filename = os.path.join(directory, "volume_changes.json")
    with open(filename, 'w') as f:
        json.dump(volume_log, f, indent=2)
    print(f"Volume saved to {filename}")