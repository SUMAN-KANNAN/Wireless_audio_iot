from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
import websockets
import os
import json
from flask_sock import Sock
from server.sock_instance import sock

audio_sessions = {}

@sock.route('/ws/audio')
def audio_socket(ws):
    print("🔗 WebSocket connected (audio)")
    room_id = "unknown"

    while True:
        try:
            message = ws.receive()
            if not message:
                break

            data = json.loads(message)
            if data.get("type") == "audio":
                room_id = data.get("roomId", "unknown")
                chunk = data.get("chunk")
                audio_sessions.setdefault(room_id, []).append(chunk)
                print(f"Received audio chunk for: {room_id}")
                save_audio_json()
        except Exception as e:
            print(f" WebSocket error for {room_id}: {e}")
            break

def save_audio_json():
    directory = "saved_audio"
    os.makedirs(directory, exist_ok=True)
    filename = os.path.join(directory, "all_audio.json")
    with open(filename, 'w') as f:
        json.dump(audio_sessions, f, indent=2)
    print(f"Audio saved to {filename}")