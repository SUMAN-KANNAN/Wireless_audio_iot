let audioContext;
let microphone;
let mediaRecorder;
let mediaStream;
let audioChunks = [];
let isMicActive = false;
let socket;

async function toggleMic(roomId) {
    let switchId = '';
    switch (roomId) {
        case 'conferenceRoom':
            switchId = 'switchConference';
            break;
        case 'adminRoom':
            switchId = 'switchAdmin';
            break;
        case 'classRoom':
            switchId = 'switchClass';
            break;
        default:
            return;
    }

    const switchElement = document.getElementById(switchId);
    if (switchElement) {
        switchElement.checked = !switchElement.checked;
        updateListeningCount();

        if (switchElement.checked) {
            await activateMicrophone(roomId);
        } else {
            deactivateMicrophone();
        }
    }
}

async function activateMicrophone(roomId) {
    if (isMicActive) return;

    try {
        socket = new WebSocket(`ws://${window.location.host}/ws/audio`);

        
        // Store the stream reference
        mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
        microphone = audioContext.createMediaStreamSource(mediaStream);
        
        mediaRecorder = new MediaRecorder(mediaStream);
        audioChunks = [];
        
        mediaRecorder.ondataavailable = (event) => {
    if (event.data.size > 0 && socket.readyState === WebSocket.OPEN) {
        const reader = new FileReader();
        reader.onloadend = function () {
            const base64data = reader.result.split(',')[1]; // Strip data URL prefix
            socket.send(JSON.stringify({
                type: "audio",
                roomId: roomId,
                chunk: base64data
            }));
        };
        reader.readAsDataURL(event.data);
    }
};

        
        mediaRecorder.start(100);
        
        isMicActive = true;
        console.log(`Microphone streaming started for ${roomId}`);
        
    } catch (error) {
        console.error('Error accessing microphone:', error);
        alert('Could not access microphone. Please ensure you have granted permission.');
    }
}

function deactivateMicrophone() {
    // Stop MediaRecorder
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
        mediaRecorder.stop();
        mediaRecorder = null;
    }
    
    // Stop all media stream tracks (this releases the microphone!)
    if (mediaStream) {
        mediaStream.getTracks().forEach(track => {
            track.stop();
            console.log('Media track stopped:', track.kind);
        });
        mediaStream = null;
    }
    
    // Disconnect audio nodes
    if (microphone) {
        microphone.disconnect();
        microphone = null;
    }
    
    // Close and suspend audio context
    if (audioContext && audioContext.state !== 'closed') {
        audioContext.close().then(() => {
            console.log('AudioContext closed');
        });
        audioContext = null;
    }
    
    // Close WebSocket
    if (socket && socket.readyState !== WebSocket.CLOSED) {
        socket.close();
        socket = null;
    }
    
    isMicActive = false;
    console.log('Microphone completely deactivated - device mic should be off');
}

// Enhanced cleanup for page unload
window.addEventListener('beforeunload', () => {
    deactivateMicrophone();
});

// Enhanced mute/unmute functions
function muteAll() {
    const switches = document.querySelectorAll('.mic-toggle');
    switches.forEach(switchElement => {
        switchElement.checked = false;
    });
    deactivateMicrophone(); // This will now properly release the microphone
    updateListeningCount();
}

function unmuteAll() {
    const switches = document.querySelectorAll('.mic-toggle');
    
    // First, make sure mic is deactivated
    deactivateMicrophone();
    
    // Then check all switches and activate the first one found
    let firstRoomId = null;
    switches.forEach(switchElement => {
        switchElement.checked = true;
        
        // Get the first room ID for activation
        if (!firstRoomId) {
            const switchId = switchElement.id;
            if (switchId.includes('Conference')) firstRoomId = 'conferenceRoom';
            else if (switchId.includes('Admin')) firstRoomId = 'adminRoom';
            else if (switchId.includes('Class')) firstRoomId = 'classRoom';
        }
    });
    
    // Activate microphone for the first room (since we can only have one active stream)
    if (firstRoomId) {
        activateMicrophone(firstRoomId);
    }
    
    updateListeningCount();
}

document.querySelectorAll('.mic-toggle').forEach(toggle => {
    toggle.addEventListener('change', updateListeningCount);
});

function updateListeningCount() {
    const toggles = document.querySelectorAll('.mic-toggle');
    let count = 0;
    toggles.forEach(toggle => {
        if (toggle.checked) count++;
    });
    document.getElementById('listeningCount').innerText = count;
}

function logout() {
    // Ensure microphone is deactivated before logout
    deactivateMicrophone();
    window.location.href = '/logout';
}

// The toggle functions for individual rooms can be removed since they are handled in toggleMic
// WebSocket for volume control
let volumeSocket = new WebSocket("ws://" + window.location.host + "/ws/volume");

function sendVolumeUpdate() {
    const conferenceVolume = document.getElementById("volumeConference").value;
    const adminVolume = document.getElementById("volumeAdmin").value;
    const classVolume = document.getElementById("volumeClass").value;

    const message = {
        type: "volume",
        data: {
            conferenceRoom: parseInt(conferenceVolume),
            adminRoom: parseInt(adminVolume),
            classRoom: parseInt(classVolume)
        }
    };

    if (volumeSocket.readyState === WebSocket.OPEN) {
        volumeSocket.send(JSON.stringify(message));
        console.log("🔊 Sent volume update:", message.data);
    }
}

// Add listeners to sliders
document.getElementById("volumeConference").addEventListener("change", sendVolumeUpdate);
document.getElementById("volumeAdmin").addEventListener("change", sendVolumeUpdate);
document.getElementById("volumeClass").addEventListener("change", sendVolumeUpdate);